python3 server.py & python3 -m Zaid
