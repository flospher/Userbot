<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="center">𝐙𝐚𝐢𝐝 𝐔𝐬𝐞𝐫𝐛𝐨𝐭 🔥 </p>

- A First Telegram Userbot Project With Multi Clients Based On PyroGram

<p align="center"><a href="https://t.me/TheUpdatesChannel"><img src="https://telegra.ph/file/723d8ef9fb7e721135221.jpg" width="300"></a></p>
<p align="center">
    <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>

## Repo Stats

![github card](https://github-readme-stats.vercel.app/api/pin/?username=ITZ-ZAID&repo=ZAID-USERBOT&theme=dark)


## Requirements 

- PyroGram Session
- Dummy account
- Python 3.8+ or 3.7
- [Mongo Db](https://youtu.be/mnvjt_a5JYA)

## String Session

<p align="center"><a href="https://replit.com/@Itz-zaid/pyrogram"> <img src="https://img.shields.io/badge/String%20Session-black?style=for-the-badge&logo=replit" width="220" height="38.45"/></a></p>


## 𝐃𝐄𝐏𝐋𝐎𝐘𝐌𝐄𝐍𝐓𝐒

ᴛᴏ ʙᴇ ꜱᴀꜰᴇ ꜰᴏʀᴋ ᴛʜɪꜱ ʀᴇᴘᴏ ᴀɴᴅ ᴛʜᴇɴ ᴘʀᴇꜱꜱ ᴅᴇᴘʟᴏʏ ʙᴜᴛᴛᴏɴ ꜰʀᴏᴍ ᴛʜᴇ ꜰᴏʀᴋᴇᴅ ʀᴇᴘᴏ 

[ꜰᴏʀᴋ ᴅᴇᴘʟᴏʏ ɪꜱ ʜɪɢʜʟʏ ʀᴇᴄᴏᴍᴍᴇɴᴅᴇᴅ](https://telegra.ph/file/5bcf79f948ca06030640c.mp4)

<p align="center"><a href="http://dashboard.heroku.com/new?template=https://github.com/Itz-Zaid/Zaid-Userbot"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-pink?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

## Features 

- **Spamming!**
- **You Can deploy Upto 10 Clients At a Same Time**
- **Almost 90+ Plugins There adding more Plugins Soon**
- **Id Safety Specially For Fake accounts**


## Deploy To Render 

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/ITZ-ZAID/ZAID-USERBOT)

## Hosting With Mogenius 

I will suggest to host on mogenius if uh don't know what is this then 
Checkout Tutorial!
<p align="center"><a href="https://youtu.be/qXT1jl60okk"> <img src="https://img.shields.io/badge/ZaidUserBot%20Deploy-black?style=for-the-badge&logo=youtube" width="220" height="38.45"/></a></p>


## VPS/Locally deploy!
```console
Zaid@Debian~ $ apt-get -y update
Zaid@Debian~ $ apt-get -y install git gcc python3-pip -y
Zaid@Debian~ $ git clone https://github.com/ITZ-ZAID/ZAID-USERBOT
Zaid@Debian~ $ cd ZAID-USERBOT
Zaid@Debian~ $ pip3 install -U -r requirements.txt
Zaid@Debian~ $ cp sample.env .env
Zaid@Debian~ $ nano .env
```

<h3 align="center">
   Edit <b>.env</b> with your own values and Run Bot
</h3>

```console
Zaid@Debian~ $ screen
Zaid@Debian~ $ python3 -m Zaid
```

## Disclaimer 


```console
      ⚠️ WARNING FOR YOU ⚠️
       Your Telegram account may get banned.
   I am not responsible for any improper use of this bot
This bot is intended for the purpose of having fun with memes,
      as well as efficiently managing groups.
You ended up spamming groups, getting reported left and right,
and you ended up in a Finale Battle with Telegram and at the end
       Telegram Team deleted your account?
  And after that, then you pointed your fingers at us
        for getting your acoount deleted?
    I will be rolling on the floor laughing at you.
```

## Credits 💖
- Zect Userbot
- Man
- pyrogram
- xyz ⚡

## Support / Channel

<p align="center">𝐒𝐮𝐩𝐩𝐨𝐫𝐭 / 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 ----> </p>

<p align="center"><a href="https://t.me/TheSupportChat"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐒𝐮𝐩𝐩𝐨𝐫𝐭-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>
<p align="center"><a href="https://t.me/TheUpdatesChannel"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐔𝐩𝐝𝐚𝐭𝐞𝐬-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>
